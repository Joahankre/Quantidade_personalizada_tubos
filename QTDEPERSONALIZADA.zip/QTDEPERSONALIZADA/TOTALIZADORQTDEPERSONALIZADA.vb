﻿Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.IO
Imports System.Windows.Forms
Imports Inventor

Public Class MultiplicadorQTDE

    Private oApp As Inventor.Application

    ' Nome padrão da propriedade personalizada
    Private Const PROPRIEDADE_QTDE As String = "QTDE PERSONALIZADA"

    Public Sub New(app As Inventor.Application)
        oApp = app
    End Sub

    ' =========================
    ' EXECUTA O MULTIPLICADOR
    ' =========================
    Public Sub Executar()
        Dim oDoc As Document = oApp.ActiveDocument

        If oDoc.DocumentType <> DocumentTypeEnum.kAssemblyDocumentObject Then
            MessageBox.Show("Esta regra só pode ser executada em um arquivo de montagem - saindo...", "Multiplicador QTDE")
            Return
        End If


        ' =========================
        ' SOLICITA MULTIPLICADOR (Windows Forms)
        ' =========================
        Dim frm As New FrmMultiplicador()
        frm.ShowDialog()

        If Not frm.Confirmado Then
            MessageBox.Show("Processo cancelado pelo usuário.", "Cancelado", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return
        End If

        Dim multiplicador As Integer = frm.Multiplicador

        If multiplicador < 1 Then
            MessageBox.Show("O multiplicador deve ser maior ou igual a 1.", "Erro")
            Return
        End If

        ' Executa os processos
        ExecutarMultiplicadorSimples(oDoc, PROPRIEDADE_QTDE, multiplicador)
        ExecutarMultiplicadorFrame(oDoc, PROPRIEDADE_QTDE, multiplicador)

        MessageBox.Show("Processo concluído com sucesso!" & vbCrLf & "Multiplicador aplicado: " & multiplicador, "Concluído", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub


    ' =================================================
    ' MULTIPLICADOR SIMPLES - Atualiza todos os documentos referenciados
    ' =================================================
    Private Sub ExecutarMultiplicadorSimples(oDoc As Document, oBOMQTY As String, multiplicador As Integer)
        Dim refDocs As DocumentsEnumerator = oDoc.AllReferencedDocuments
        Dim assemblyDoc As AssemblyDocument = oDoc
        Dim assemblyDef As AssemblyComponentDefinition = assemblyDoc.ComponentDefinition

        Dim oProgressBar As Inventor.ProgressBar = oApp.CreateProgressBar(False, refDocs.Count, "Atualizando: Etapa 0 de " & refDocs.Count)
        Dim oProgressStep As Integer = 0

        For Each docFile As Document In refDocs
            Try
                Dim partQty As Object = assemblyDef.Occurrences.AllReferencedOccurrences(docFile)
                Dim qtdeTotal As Integer = partQty.Count * multiplicador

                Try
                    docFile.PropertySets.Item("Inventor User Defined Properties").Item(oBOMQTY).Value = qtdeTotal
                Catch
                    docFile.PropertySets.Item("Inventor User Defined Properties").Add(qtdeTotal, oBOMQTY)
                End Try
            Catch
                ' Ignora erros
            End Try

            ' Atualiza barra de progresso
            oProgressStep += 1
            oProgressBar.Message = "Atualizando: Etapa " & oProgressStep & " de " & refDocs.Count
            oProgressBar.UpdateProgress()
        Next

        ' Atualiza a própria montagem
        Try
            oDoc.PropertySets.Item("Inventor User Defined Properties").Item(oBOMQTY).Value = multiplicador
        Catch
            oDoc.PropertySets.Item("Inventor User Defined Properties").Add(multiplicador, oBOMQTY)
        End Try

        oProgressBar.Close()
    End Sub

    ' =================================================
    ' MULTIPLICADOR FRAME - somente filhos dos frames
    ' =================================================
    Private Sub ExecutarMultiplicadorFrame(oDoc As Document, oBOMQTY As String, multiplicadorGlobal As Integer)
        Dim asmDoc As AssemblyDocument = oDoc
        Dim bom As BOM = asmDoc.ComponentDefinition.BOM
        bom.StructuredViewEnabled = True

        Dim modelDataView As BOMView = ObterModelDataBOMView(bom)
        If modelDataView Is Nothing Then
            MessageBox.Show("BOM View do tipo Model Data não encontrada.", "Erro")
            Return
        End If

        Dim frameRows As List(Of BOMRow) = ObterMontagensFrame(modelDataView)
        If frameRows.Count = 0 Then Return

        Dim oProgressBar As Inventor.ProgressBar = CriarProgressBar(frameRows.Count, "Atualizando montagens Frame individualmente...")

        For Each frameRow As BOMRow In frameRows
            ProcessarFrame(frameRow, oBOMQTY, multiplicadorGlobal, oProgressBar)
        Next

        oProgressBar.Close()
    End Sub

    ' =========================
    ' FUNÇÕES AUXILIARES
    ' =========================

    Private Function ObterModelDataBOMView(bom As BOM) As BOMView
        For Each view As BOMView In bom.BOMViews
            If view.ViewType = BOMViewTypeEnum.kModelDataBOMViewType Then Return view
        Next
        Return Nothing
    End Function

    Private Function ObterMontagensFrame(modelDataView As BOMView) As List(Of BOMRow)
        Dim frameRows As New List(Of BOMRow)
        For Each row As BOMRow In modelDataView.BOMRows
            ColetarMontagensFrameRecursivo(row, frameRows)
        Next
        Return frameRows
    End Function

    Private Sub ColetarMontagensFrameRecursivo(row As BOMRow, lista As List(Of BOMRow))
        Try
            If row.ComponentDefinitions.Count > 0 Then
                Dim compDef As ComponentDefinition = row.ComponentDefinitions.Item(1)
                Dim doc As Document = compDef.Document
                Dim partNumber As String = ""
                Try
                    partNumber = doc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value.ToString()
                Catch
                End Try

                If partNumber.StartsWith("Frame", StringComparison.InvariantCultureIgnoreCase) Then
                    lista.Add(row)
                End If

                If Not partNumber.StartsWith("Skeleton", StringComparison.InvariantCultureIgnoreCase) Then
                    If row.ChildRows IsNot Nothing Then
                        For Each child As BOMRow In row.ChildRows
                            ColetarMontagensFrameRecursivo(child, lista)
                        Next
                    End If
                End If
            End If
        Catch
        End Try
    End Sub

    Private Sub ProcessarFrame(frameRow As BOMRow, oBOMQTY As String, multiplicadorGlobal As Integer, oProgressBar As Inventor.ProgressBar)
        Try
            Dim partCount As Dictionary(Of String, Integer) = ContarPartesPorMassa(frameRow)
            Dim frameMultiplicador As Integer = ObterMultiplicadorFrame(frameRow)
            Dim partCountMultiplicado As Dictionary(Of String, Integer) = AplicarMultiplicador(partCount, multiplicadorGlobal, frameMultiplicador)
            AtualizarPropriedadesPersonalizadasFilhos(oBOMQTY, partCountMultiplicado, oProgressBar)
        Catch
        End Try
    End Sub

    Private Function ObterMultiplicadorFrame(frameRow As BOMRow) As Integer
        Try
            Dim customProps As PropertySet = frameRow.ComponentDefinitions.Item(1).Document.PropertySets.Item("Inventor User Defined Properties")
            Return CInt(customProps.Item(PROPRIEDADE_QTDE).Value)
        Catch
            Return 1
        End Try
    End Function

    Private Function ContarPartesPorMassa(frameRow As BOMRow) As Dictionary(Of String, Integer)
        Dim partCount As New Dictionary(Of String, Integer)(StringComparer.InvariantCultureIgnoreCase)
        If frameRow.ChildRows IsNot Nothing Then
            For Each child As BOMRow In frameRow.ChildRows
                ContarPartesPorMassaRecursivo(child, partCount)
            Next
        End If
        Return partCount
    End Function

    Private Sub ContarPartesPorMassaRecursivo(row As BOMRow, dict As Dictionary(Of String, Integer))
        Try
            If row.ComponentDefinitions.Count > 0 Then
                Dim compDef As ComponentDefinition = row.ComponentDefinitions.Item(1)
                Dim doc As Document = compDef.Document

                Dim partNumber As String = "(sem PN)"
                Dim massa As Double = 0.0

                Try
                    partNumber = doc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value.ToString()
                Catch
                End Try

                Try
                    massa = doc.ComponentDefinition.MassProperties.Mass
                Catch
                End Try

                Dim key As String = partNumber & "|" & Math.Round(massa, 5).ToString()
                If dict.ContainsKey(key) Then
                    dict(key) += 1
                Else
                    dict.Add(key, 1)
                End If
            End If

            If row.ChildRows IsNot Nothing Then
                For Each child As BOMRow In row.ChildRows
                    ContarPartesPorMassaRecursivo(child, dict)
                Next
            End If
        Catch
        End Try
    End Sub

    Private Function AplicarMultiplicador(partCount As Dictionary(Of String, Integer), multiplicadorGlobal As Integer, frameMultiplicador As Integer) As Dictionary(Of String, Integer)
        Dim partCountMultiplicado As New Dictionary(Of String, Integer)(StringComparer.InvariantCultureIgnoreCase)
        For Each kvp As KeyValuePair(Of String, Integer) In partCount
            partCountMultiplicado.Add(kvp.Key, kvp.Value * frameMultiplicador * multiplicadorGlobal)
        Next
        Return partCountMultiplicado
    End Function

    Private Sub AtualizarPropriedadesPersonalizadasFilhos(oBOMQTY As String, dict As Dictionary(Of String, Integer), oProgressBar As Inventor.ProgressBar)
        Dim oProgressStep As Integer = 0
        For Each kvp As KeyValuePair(Of String, Integer) In dict
            AtualizarPropriedadeFilho(kvp, oBOMQTY)
            oProgressStep += 1
            oProgressBar.Message = $"Atualizando Tubos: {oProgressStep} de {dict.Count}"
            oProgressBar.UpdateProgress()
        Next
    End Sub

    Private Sub AtualizarPropriedadeFilho(kvp As KeyValuePair(Of String, Integer), oBOMQTY As String)
        Dim keyParts() As String = kvp.Key.Split("|"c)
        Dim partNumber As String = keyParts(0)
        Dim massaKey As Double = CDbl(keyParts(1))

        For Each doc As Document In oApp.Documents
            Try
                If doc.DocumentType = DocumentTypeEnum.kAssemblyDocumentObject Then Continue For

                Dim pn As String = ""
                Try
                    pn = doc.PropertySets.Item("Design Tracking Properties").Item("Part Number").Value.ToString()
                Catch
                End Try

                If pn.Equals(partNumber, StringComparison.InvariantCultureIgnoreCase) Then
                    Dim massaDoc As Double = 0.0
                    Try
                        massaDoc = doc.ComponentDefinition.MassProperties.Mass
                    Catch
                    End Try

                    If Math.Abs(massaDoc - massaKey) < 0.00001 Then
                        Dim customProps As PropertySet = doc.PropertySets.Item("Inventor User Defined Properties")
                        Try
                            customProps.Item(oBOMQTY).Value = kvp.Value
                        Catch
                            customProps.Add(kvp.Value, oBOMQTY)
                        End Try
                        doc.Update()
                    End If
                End If
            Catch
            End Try
        Next
    End Sub

    Private Function CriarProgressBar(totalEtapas As Integer, mensagemInicial As String) As Inventor.ProgressBar
        Try
            Dim oProgressBar As Inventor.ProgressBar = oApp.CreateProgressBar(False, totalEtapas, mensagemInicial)
            oProgressBar.Message = mensagemInicial
            oProgressBar.UpdateProgress()
            Return oProgressBar
        Catch ex As Exception
            MessageBox.Show("Erro ao criar barra de progresso: " & ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return Nothing
        End Try
    End Function

End Class
