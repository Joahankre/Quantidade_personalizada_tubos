﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmIGSExporter
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnSelecionarTodas = New System.Windows.Forms.Button()
        Me.btnDesmarcarTodas = New System.Windows.Forms.Button()
        Me.btnSelecionarPrefixo = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.chkSelecionar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.txtNome = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.imgMiniatura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.btnExportarIGES = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnSelecionarTodas
        '
        Me.btnSelecionarTodas.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSelecionarTodas.Font = New System.Drawing.Font("Swis721 Blk BT", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSelecionarTodas.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.btnSelecionarTodas.Location = New System.Drawing.Point(3, 3)
        Me.btnSelecionarTodas.Name = "btnSelecionarTodas"
        Me.btnSelecionarTodas.Size = New System.Drawing.Size(400, 40)
        Me.btnSelecionarTodas.TabIndex = 2
        Me.btnSelecionarTodas.Text = "Selecionar Todas"
        Me.btnSelecionarTodas.UseVisualStyleBackColor = False
        '
        'btnDesmarcarTodas
        '
        Me.btnDesmarcarTodas.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnDesmarcarTodas.Font = New System.Drawing.Font("Swis721 Blk BT", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDesmarcarTodas.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDesmarcarTodas.Location = New System.Drawing.Point(409, 3)
        Me.btnDesmarcarTodas.Name = "btnDesmarcarTodas"
        Me.btnDesmarcarTodas.Size = New System.Drawing.Size(400, 40)
        Me.btnDesmarcarTodas.TabIndex = 3
        Me.btnDesmarcarTodas.Text = "Desmarcar Todas"
        Me.btnDesmarcarTodas.UseVisualStyleBackColor = False
        '
        'btnSelecionarPrefixo
        '
        Me.btnSelecionarPrefixo.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnSelecionarPrefixo.Font = New System.Drawing.Font("Swis721 Blk BT", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSelecionarPrefixo.Location = New System.Drawing.Point(3, 47)
        Me.btnSelecionarPrefixo.Name = "btnSelecionarPrefixo"
        Me.btnSelecionarPrefixo.Size = New System.Drawing.Size(400, 40)
        Me.btnSelecionarPrefixo.TabIndex = 4
        Me.btnSelecionarPrefixo.Text = "Selecionar por Prefixo"
        Me.btnSelecionarPrefixo.UseVisualStyleBackColor = False
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.HighlightText
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.chkSelecionar, Me.txtNome, Me.imgMiniatura})
        Me.DataGridView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView1.GridColor = System.Drawing.SystemColors.WindowText
        Me.DataGridView1.Location = New System.Drawing.Point(0, 0)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 70
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(1536, 823)
        Me.DataGridView1.TabIndex = 7
        '
        'chkSelecionar
        '
        Me.chkSelecionar.FillWeight = 52.94118!
        Me.chkSelecionar.HeaderText = "Selecionar"
        Me.chkSelecionar.MinimumWidth = 30
        Me.chkSelecionar.Name = "chkSelecionar"
        '
        'txtNome
        '
        Me.txtNome.FillWeight = 194.1176!
        Me.txtNome.HeaderText = "Nome da Folha"
        Me.txtNome.MinimumWidth = 300
        Me.txtNome.Name = "txtNome"
        '
        'imgMiniatura
        '
        Me.imgMiniatura.FillWeight = 52.94118!
        Me.imgMiniatura.HeaderText = "Miniatura"
        Me.imgMiniatura.MinimumWidth = 6
        Me.imgMiniatura.Name = "imgMiniatura"
        '
        'ComboBox1
        '
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(409, 50)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(806, 37)
        Me.ComboBox1.TabIndex = 8
        '
        'btnExportarIGES
        '
        Me.btnExportarIGES.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnExportarIGES.Font = New System.Drawing.Font("Swis721 Blk BT", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExportarIGES.ForeColor = System.Drawing.Color.DarkGreen
        Me.btnExportarIGES.Location = New System.Drawing.Point(815, 3)
        Me.btnExportarIGES.Name = "btnExportarIGES"
        Me.btnExportarIGES.Size = New System.Drawing.Size(400, 40)
        Me.btnExportarIGES.TabIndex = 9
        Me.btnExportarIGES.Text = "Exportar IGS"
        Me.btnExportarIGES.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.PowderBlue
        Me.Panel1.Controls.Add(Me.btnExportarIGES)
        Me.Panel1.Controls.Add(Me.btnSelecionarTodas)
        Me.Panel1.Controls.Add(Me.btnDesmarcarTodas)
        Me.Panel1.Controls.Add(Me.btnSelecionarPrefixo)
        Me.Panel1.Controls.Add(Me.ComboBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 724)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1536, 99)
        Me.Panel1.TabIndex = 10
        '
        'FrmIGSExporter
        '
        Me.BackColor = System.Drawing.Color.Blue
        Me.ClientSize = New System.Drawing.Size(1536, 823)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "FrmIGSExporter"
        Me.Text = "Developed by Kreimeier & Machado – Folhas de Desenho: Seleção para Expotação ( Ma" &
    "rque as folhas que deseja incluir na exportação IGS )"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents clbSheets As Windows.Forms.CheckedListBox
    Friend WithEvents btnSelectAll As Windows.Forms.Button
    Friend WithEvents btnDeselectAll As Windows.Forms.Button
    Friend WithEvents btnSelectByPrefix As Windows.Forms.Button
    Friend WithEvents btnConfirm As Windows.Forms.Button
    Friend WithEvents FlowLayoutPanel1 As Windows.Forms.FlowLayoutPanel
    Friend WithEvents btnSelecionarTodas As Windows.Forms.Button
    Friend WithEvents btnDesmarcarTodas As Windows.Forms.Button
    Friend WithEvents btnSelecionarPrefixo As Windows.Forms.Button
    Friend WithEvents ImageList1 As Windows.Forms.ImageList
    Friend WithEvents DataGridView1 As Windows.Forms.DataGridView
    Friend WithEvents chkSelecionar As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents txtNome As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents imgMiniatura As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComboBox1 As Windows.Forms.ComboBox
    Friend WithEvents btnExportarIGES As Windows.Forms.Button
    Friend WithEvents Panel1 As Windows.Forms.Panel
End Class
