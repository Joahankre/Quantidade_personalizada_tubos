﻿Imports System.Windows.Forms

Public Class FrmMultiplicador
    Inherits Form

    ' Propriedades públicas
    Public Property Multiplicador As Integer = 1
    Public Property Confirmado As Boolean = False

    ' Controles do formulário com nomes exclusivos
    Private lblMensagemMultiplicador As Label
    Private txtMultiplicadorValor As TextBox
    Private btnConfirmarMultiplicador As Button
    Private btnCancelarMultiplicador As Button



    Public Sub New()
        ' Configurações do formulário
        Me.Text = "Multiplicador de Projeto"
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.MinimumSize = New Drawing.Size(400, 140)
        Me.AutoSize = True
        Me.AutoSizeMode = AutoSizeMode.GrowAndShrink



        ' Layout dinâmico
        Dim mainPanel As New TableLayoutPanel()
        mainPanel.Dock = DockStyle.Fill
        mainPanel.ColumnCount = 2
        mainPanel.RowCount = 3
        mainPanel.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50))
        mainPanel.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 50))
        mainPanel.RowStyles.Add(New RowStyle(SizeType.AutoSize))
        mainPanel.RowStyles.Add(New RowStyle(SizeType.AutoSize))
        mainPanel.RowStyles.Add(New RowStyle(SizeType.AutoSize))
        mainPanel.Padding = New Padding(10)
        Me.Controls.Add(mainPanel)

        ' Label
        lblMensagemMultiplicador = New Label()
        lblMensagemMultiplicador.Text = "Digite a quantidade de vezes que este projeto será produzido:"
        lblMensagemMultiplicador.AutoSize = True
        lblMensagemMultiplicador.Dock = DockStyle.Fill
        lblMensagemMultiplicador.TextAlign = Drawing.ContentAlignment.MiddleLeft
        mainPanel.Controls.Add(lblMensagemMultiplicador, 0, 0)
        mainPanel.SetColumnSpan(lblMensagemMultiplicador, 2)

        ' TextBox
        txtMultiplicadorValor = New TextBox()
        txtMultiplicadorValor.Text = "1"
        txtMultiplicadorValor.Dock = DockStyle.Fill
        mainPanel.Controls.Add(txtMultiplicadorValor, 0, 1)
        mainPanel.SetColumnSpan(txtMultiplicadorValor, 2)

        ' Botão Confirmar
        btnConfirmarMultiplicador = New Button()
        btnConfirmarMultiplicador.Text = "OK"
        btnConfirmarMultiplicador.Dock = DockStyle.Fill
        AddHandler btnConfirmarMultiplicador.Click, AddressOf btnConfirmarMultiplicador_Click
        mainPanel.Controls.Add(btnConfirmarMultiplicador, 0, 2)

        ' Botão Cancelar
        btnCancelarMultiplicador = New Button()
        btnCancelarMultiplicador.Text = "Cancelar"
        btnCancelarMultiplicador.Dock = DockStyle.Fill
        AddHandler btnCancelarMultiplicador.Click, AddressOf btnCancelarMultiplicador_Click
        mainPanel.Controls.Add(btnCancelarMultiplicador, 1, 2)
    End Sub

    ' Clique no botão Confirmar
    Private Sub btnConfirmarMultiplicador_Click(sender As Object, e As EventArgs)
        Dim valor As Integer
        If Integer.TryParse(txtMultiplicadorValor.Text, valor) AndAlso valor >= 1 Then
            Multiplicador = valor
            Confirmado = True
            Me.Close()
        Else
            MessageBox.Show("Valor inválido. Digite um número inteiro maior ou igual a 1.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    ' Clique no botão Cancelar
    Private Sub btnCancelarMultiplicador_Click(sender As Object, e As EventArgs)
        Confirmado = False
        Me.Close()
    End Sub

    Private Sub FrmMultiplicador_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
