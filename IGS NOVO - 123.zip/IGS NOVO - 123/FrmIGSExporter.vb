﻿Imports System.Windows.Forms
Imports Inventor
Imports System.Drawing
Imports System.Runtime.InteropServices

Public Class FrmIGSExporter

    Private _sheets As Sheets
    Private _invApp As Inventor.Application

    ' Construtor
    Public Sub New(invApp As Inventor.Application)
        InitializeComponent()
        _invApp = invApp
    End Sub

    ' Inicializa folhas
    Public Sub SetSheets(sheets As Sheets)
        _sheets = sheets
        CarregarFolhas()
    End Sub
    '==========================================
    ' Evento para ajustar altura de múltiplas linhas
    ' ==========================================
    Private Sub DataGridView1_RowHeightChanged(sender As Object, e As DataGridViewRowEventArgs) Handles DataGridView1.RowHeightChanged
        Dim selecionadas = DataGridView1.SelectedRows
        If selecionadas.Count > 1 Then
            Dim altura = e.Row.Height
            For Each row As DataGridViewRow In selecionadas
                If row.Index <> e.Row.Index Then
                    row.Height = altura
                End If
            Next
        End If
    End Sub

    ' ================================================================
    ' === CARREGA FOLHAS E MINIATURAS ===============================
    ' ================================================================
    Private Sub CarregarFolhas()
        DataGridView1.Columns.Clear()
        DataGridView1.Rows.Clear()
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.RowTemplate.Height = 50

        Dim colSelecionar As New DataGridViewCheckBoxColumn() With {
            .Name = "chkSelecionar",
            .HeaderText = "Selecionar",
            .Width = 30
        }
        Dim colNome As New DataGridViewTextBoxColumn() With {
            .Name = "txtNome",
            .HeaderText = "Nome da Folha",
            .Width = 300,
            .ReadOnly = True
        }
        Dim colMiniatura As New DataGridViewImageColumn() With {
            .Name = "imgMiniatura",
            .HeaderText = "Miniatura",
            .Width = 70,
            .ImageLayout = DataGridViewImageCellLayout.Zoom
        }

        DataGridView1.Columns.AddRange({colSelecionar, colNome, colMiniatura})

        For Each sheet As Sheet In _sheets
            Dim bmp = GerarMiniaturaDoModeloReferenciado(sheet)
            DataGridView1.Rows.Add(Not sheet.ExcludeFromPrinting, sheet.Name, bmp)

            DataGridView1.Rows(DataGridView1.Rows.Count - 1).Tag = sheet
        Next
    End Sub

    ' ================================================================
    ' === GERA MINIATURAS DE DOCUMENTOS REFERENCIADOS ===============
    ' ================================================================
    Private Function GerarMiniaturaDoModeloReferenciado(sheet As Sheet) As Bitmap
        Try
            If sheet.DrawingViews.Count = 0 Then Return GerarMiniaturaPadrao(sheet.Name)

            Dim refDoc = sheet.DrawingViews.Item(1).ReferencedDocumentDescriptor.ReferencedDocument
            If refDoc Is Nothing Then Return GerarMiniaturaPadrao(sheet.Name)

            Dim bmp = ObterMiniaturaEficiente(refDoc)
            If bmp IsNot Nothing Then Return bmp
            Return GerarMiniaturaPadrao(refDoc.DisplayName)

        Catch
            Return GerarMiniaturaPadrao(sheet.Name)
        End Try
    End Function

    ' ================================================================
    ' === MÉTODO EFICIENTE  =======================
    ' ================================================================
    Private Function ObterMiniaturaEficiente(doc As Inventor.Document) As Bitmap
        If doc Is Nothing Then Return Nothing

        Dim oThumb As stdole.IPictureDisp = Nothing

        ' Espera até o handle estar pronto
        Dim tentativas As Integer = 0
        Do
            Try
                oThumb = doc.Thumbnail
            Catch
                System.Threading.Thread.Sleep(50)
            End Try

            tentativas += 1
            If tentativas > 50 Then Exit Do ' timeout de ~2,5s para evitar travar
        Loop While (oThumb Is Nothing OrElse oThumb.Handle < 0)

        If oThumb Is Nothing Then Return Nothing

        Try
            Dim conv As New AxHostConverter()
            Dim img As Image = conv.GetImageFromIPictureDisp(oThumb)

            ' Gera uma miniatura menor (melhor qualidade)
            Dim callback As New Image.GetThumbnailImageAbort(Function() False)
            Dim thumb As Image = img.GetThumbnailImage(180, 180, callback, IntPtr.Zero)
            Return CType(thumb, Bitmap)
        Catch
            Return Nothing
        End Try
    End Function

    ' ================================================================
    ' === MINIATURA PADRÃO (FALHA OU SEM REFERÊNCIA) =================
    ' ================================================================
    Private Function GerarMiniaturaPadrao(nome As String) As Bitmap
        Dim bmp As New Bitmap(120, 120)
        Using g As Graphics = Graphics.FromImage(bmp)
            g.Clear(System.Drawing.Color.LightGray)
            g.DrawRectangle(Pens.Gray, 0, 0, bmp.Width - 1, bmp.Height - 1)
            g.DrawString(nome, New Font("Arial", 8, FontStyle.Bold),
                         Brushes.Black, New PointF(5, 40))
        End Using
        Return bmp
    End Function

    ' ================================================================
    ' === BOTÕES =====================================================
    ' ================================================================
    Private Sub btnSelecionarTodas_Click(sender As Object, e As EventArgs) Handles btnSelecionarTodas.Click
        For Each row As DataGridViewRow In DataGridView1.Rows
            row.Cells("chkSelecionar").Value = True
        Next
    End Sub

    Private Sub btnDesmarcarTodas_Click(sender As Object, e As EventArgs) Handles btnDesmarcarTodas.Click
        For Each row As DataGridViewRow In DataGridView1.Rows
            row.Cells("chkSelecionar").Value = False
        Next
    End Sub


    Private Sub FrmIGSExporter_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Lista completa de categorias
        Dim categoriasDisponiveis As New List(Of String) From {
        "27 - INTERNO - CORTE LASER CH",
        "47 - INTERNO - CORTE LASER TB",
        "30 - INTERNO - SERRA FITA",
        "33 - INTERNO - USINAGEM",
        "28 - INTERNO - DOBRA",
        "38 - INTERNO - ELÉTRICA / AUTOMAÇÃO",
        "29 - INTERNO - MONTAGEM / SOLDA",
        "32 - INTERNO - MONTAGEM FINAL",
        "42 - EXTERNO - USINAGEM – POLÍMEROS",
        "43 - EXTERNO - USINAGEM – ALUMÍNIO",
        "44 - EXTERNO - USINAGEM – POLICARBONATO",
        "45 - EXTERNO - USINAGEM – ELETROFUSÃO",
        "46 - EXTERNO - USINAGEM – INOX"
    }

        ' Adiciona os textos completos no ComboBox
        ComboBox1.Items.AddRange(categoriasDisponiveis.ToArray())
    End Sub

    Private Sub btnSelecionarPrefixo_Click(sender As Object, e As EventArgs) Handles btnSelecionarPrefixo.Click
        If String.IsNullOrWhiteSpace(ComboBox1.Text) Then
            MessageBox.Show("Selecione uma categoria antes de continuar.", "Categoria obrigatória",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Extrai apenas o prefixo numérico antes do primeiro " - "
        Dim textoCompleto As String = ComboBox1.Text.Trim()
        Dim prefixo As String = textoCompleto.Split("-"c)(0).Trim()

        Dim selecionadas As Integer = 0

        ' Marca todas as folhas cujo nome começa com o prefixo
        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim nomeFolha As String = row.Cells("txtNome").Value.ToString()
            If nomeFolha.StartsWith(prefixo, StringComparison.OrdinalIgnoreCase) Then
                row.Cells("chkSelecionar").Value = True
                selecionadas += 1
            End If
        Next

        MessageBox.Show($"{selecionadas} folhas marcadas com o prefixo {prefixo}.", "Seleção concluída",
                    MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub btnSelecionarFrameGenerator_Click(sender As Object, e As EventArgs) Handles btnSelecionarFrameGenerator.Click
        Dim selecionadas As Integer = 0

        ' Percorre todas as linhas do DataGridView
        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim sheet As Sheet = CType(row.Tag, Sheet)
            Dim marcarLinha As Boolean = False

            ' Percorre todas as views da folha
            For Each drawingView As DrawingView In sheet.DrawingViews
                If drawingView.ReferencedDocumentDescriptor Is Nothing Then Continue For

                Dim oModel As Document = drawingView.ReferencedDocumentDescriptor.ReferencedDocument
                If oModel Is Nothing OrElse oModel.DocumentType <> DocumentTypeEnum.kPartDocumentObject Then Continue For

                ' Verifica se é Frame Generator
                If oModel.DocumentInterests.HasInterest("{AC211AE0-A7A5-4589-916D-81C529DA6D17}") Then
                    marcarLinha = True
                    Exit For ' Se encontrar pelo menos uma view com Frame Generator, marca a folha
                End If
            Next

            ' Marca o checkbox
            If marcarLinha Then
                row.Cells("chkSelecionar").Value = True
                selecionadas += 1
            End If
        Next

        MessageBox.Show($"{selecionadas} folhas foram selecionadas contendo peças geradas pelo Frame Generator.", "Seleção Concluída",
                    MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub


    Private Sub btnConfirmar_Click(sender As Object, e As EventArgs)
        Try
            For Each row As DataGridViewRow In DataGridView1.Rows
                Dim sheet As Sheet = CType(row.Tag, Sheet)
                Dim selecionada As Boolean = CBool(row.Cells("chkSelecionar").Value)
                sheet.ExcludeFromPrinting = Not selecionada
            Next

            MessageBox.Show("Configuração de impressão atualizada com sucesso!",
                            "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Me.DialogResult = DialogResult.OK
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("Erro ao atualizar folhas: " & ex.Message, "Erro",
                            MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    ' ================================================================
    ' === OBTÉM LISTA DE FOLHAS SELECIONADAS =========================
    ' ================================================================
    Public Function ObterFolhasSelecionadas() As List(Of Sheet)
        Dim selecionadas As New List(Of Sheet)
        For Each row As DataGridViewRow In DataGridView1.Rows
            If CBool(row.Cells("chkSelecionar").Value) Then
                selecionadas.Add(CType(row.Tag, Sheet))
            End If
        Next
        Return selecionadas
    End Function
    ' Extrai número da página de uma folha (ex: "27:3" → "003")
    Private Function ExtrairNumeroPagina(sheetName As String) As String
        Try
            Dim partes = sheetName.Split(":"c)
            If partes.Length > 1 Then
                Dim num As Integer
                If Integer.TryParse(partes.Last(), num) Then
                    Return num.ToString("D3")
                End If
            End If
        Catch
        End Try
        Return "000"
    End Function

    ' Obtém uma propriedade do modelo (User Defined ou padrão)
    Private Function ObterPropriedade(modelDoc As PartDocument, propName As String, defaultValue As String) As String
        Try
            Dim userProps = modelDoc.PropertySets.Item("User Defined Properties")
            Return userProps.Item(propName).Value.ToString()
        Catch
            Return defaultValue
        End Try
    End Function

    ' Captura parâmetros G_H, G_W, G_T convertidos para mm
    ' Captura parâmetros G_H, G_W, G_T convertidos para mm
    Private Sub ObterDimensoes(modelDoc As PartDocument, ByRef dim1 As String, ByRef dim2 As String, ByRef dim3 As String)
        dim1 = "00" : dim2 = "00" : dim3 = "0.00"
        Try
            Dim cd = modelDoc.ComponentDefinition
            dim1 = (cd.Parameters.Item("G_H").Value * 10).ToString("00")
            dim2 = (cd.Parameters.Item("G_W").Value * 10).ToString("00")
            dim3 = (cd.Parameters.Item("G_T").Value * 10).ToString("0.00")
        Catch
        End Try
    End Sub

    ' ============================================================
    ' === EXPORTAR IGES DIRETAMENTE DO ADD-IN =====================
    ' ============================================================
    Private Sub btnExportarIGES_Click(sender As Object, e As EventArgs) Handles btnExportarIGES.Click
        Try
            ' --- Obter folhas selecionadas ---
            Dim folhasSelecionadas As List(Of Sheet) = ObterFolhasSelecionadas()
            If folhasSelecionadas.Count = 0 Then
                MessageBox.Show("Nenhuma folha selecionada para exportar.", "Aviso",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return
            End If

            ' --- Solicitar prefixo ---
            Dim prefixo As String = InputBox("Insira o prefixo para o nome dos arquivos IGES:", "Prefixo IGES")
            If String.IsNullOrWhiteSpace(prefixo) Then
                MessageBox.Show("Prefixo inválido. A exportação foi cancelada.")
                Return
            End If

            ' --- Escolher pasta destino ---
            Using folderDialog As New FolderBrowserDialog With {
            .Description = "Selecione a pasta onde os arquivos IGES serão salvos",
            .ShowNewFolderButton = True
        }
                If folderDialog.ShowDialog() <> DialogResult.OK Then
                    MessageBox.Show("Nenhuma pasta foi selecionada. A exportação foi cancelada.")
                    Return
                End If

                Dim pastaDestino As String = folderDialog.SelectedPath

                ' --- Tradutor IGES ---
                Dim igesAddIn As TranslatorAddIn =
                _invApp.ApplicationAddIns.ItemById("{90AF7F44-0C01-11D5-8E83-0010B541CD80}")

                If igesAddIn Is Nothing Then
                    MessageBox.Show("Tradutor IGES não encontrado.", "Erro",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return
                End If

                Dim oContext As TranslationContext = _invApp.TransientObjects.CreateTranslationContext
                Dim oOptions As NameValueMap = _invApp.TransientObjects.CreateNameValueMap
                oContext.Type = IOMechanismEnum.kFileBrowseIOMechanism

                ' Configurações padrão do IGES
                If igesAddIn.HasSaveCopyAsOptions(_invApp.ActiveDocument, oContext, oOptions) Then
                    oOptions.Value("GeometryType") = 0
                    oOptions.Value("SolidFaceType") = 0
                    oOptions.Value("SurfaceType") = 1
                End If

                Dim docDesenho As DrawingDocument = CType(_invApp.ActiveDocument, DrawingDocument)

                ' --- Loop pelas folhas selecionadas ---
                For Each sheet As Sheet In folhasSelecionadas
                    For Each view As DrawingView In sheet.DrawingViews
                        Try
                            If view.ReferencedDocumentDescriptor Is Nothing Then Continue For
                            Dim refDoc As Document = view.ReferencedDocumentDescriptor.ReferencedDocument
                            If refDoc Is Nothing Then Continue For

                            ' Somente peças
                            If refDoc.DocumentType <> DocumentTypeEnum.kPartDocumentObject Then Continue For

                            Dim modelPath As String = refDoc.FullFileName
                            If String.IsNullOrEmpty(modelPath) OrElse Not IO.File.Exists(modelPath) Then
                                MessageBox.Show($"Modelo não encontrado para a vista '{view.Name}' da folha '{sheet.Name}'.")
                                Continue For
                            End If

                            ' Abrir documento do modelo
                            Dim modelDoc As PartDocument = _invApp.Documents.Open(modelPath, True)
                            If modelDoc.Dirty Then modelDoc.Save()

                            ' --- Nome IGES ---
                            Dim pageNumber As String = ExtrairNumeroPagina(sheet.Name)
                            Dim qtdePersonalizada As String = ObterPropriedade(modelDoc, "QTDE PERSONALIZADA", "000").PadLeft(3, "0"c) & "X"

                            Dim dim1 As String, dim2 As String, dim3 As String
                            ObterDimensoes(modelDoc, dim1, dim2, dim3)


                            ' --- Nome formatado exatamente como no iLogic ---
                            Dim formattedDim1 As String = CDbl(dim1).ToString("00")
                            Dim formattedDim2 As String = CDbl(dim2).ToString("00")
                            Dim formattedDim3 As String = CDbl(dim3).ToString("0.00")

                            ' Garantir formato da quantidade personalizada
                            Dim formattedQtde As String = qtdePersonalizada.PadLeft(3, "0"c)
                            If Not formattedQtde.EndsWith("X") Then
                                formattedQtde &= "X"
                            End If

                            ' Montagem final do nome
                            Dim igesFileName As String = IO.Path.Combine(pastaDestino,
                            $"{prefixo}-{pageNumber}-{formattedDim1}X{formattedDim2}X#{formattedDim3}-{formattedQtde}.igs")


                            Dim oData As DataMedium = _invApp.TransientObjects.CreateDataMedium
                            oData.FileName = igesFileName

                            ' --- Exportar ---
                            igesAddIn.SaveCopyAs(modelDoc, oContext, oOptions, oData)

                            modelDoc.Close(True)
                        Catch ex As Exception
                            MessageBox.Show($"Erro ao exportar folha '{sheet.Name}': {ex.Message}")
                        End Try
                    Next
                Next

                MessageBox.Show("Exportação IGES concluída com sucesso!", "Concluído",
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
            End Using

        Catch ex As Exception
            MessageBox.Show("Erro inesperado: " & ex.Message, "Erro",
                        MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class

' ================================================================
' === CONVERSOR AxHost (igual ao do iLogic) ======================
' ================================================================
Public Class AxHostConverter
    Inherits System.Windows.Forms.AxHost
    Public Sub New()
        MyBase.New((New Guid).ToString)
    End Sub
    Public Function GetImageFromIPictureDisp(ByVal IPDisp As stdole.IPictureDisp) As Image
        Return MyBase.GetPictureFromIPicture(IPDisp)
    End Function
End Class

