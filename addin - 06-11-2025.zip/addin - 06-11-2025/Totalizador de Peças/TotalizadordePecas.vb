﻿Option Strict Off
Imports System.Reflection
Imports System.Windows.Forms
Imports Inventor
Imports IO = System.IO ' Alias para System.IO para evitar ambiguidade com Inventor

Public Class TotalizadordePecas
    Private ReadOnly _app As Inventor.Application
    Private _regraExecutada As Boolean = False ' Evita execução duplicada

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub ExecutarTotalizadorPecas()
        ' Evita executar mais de uma vez
        If _regraExecutada Then Return
        _regraExecutada = True

        Dim tempFilePath As String = Nothing

        Try
            ' Lê o código iLogic embutido
            Dim codigoIlogic As String = LerRegraIncorporada("ilogic")
            If String.IsNullOrWhiteSpace(codigoIlogic) Then
                MsgBox("Não foi possível carregar a regra iLogic incorporada.")
                Return
            End If

            ' Documento ativo
            Dim doc As Document = _app.ActiveDocument
            If doc Is Nothing Then
                MsgBox("Nenhum documento ativo.")
                Return
            End If

            ' Obtém o Add-In iLogic
            Dim iLogicAddIn As ApplicationAddIn =
                _app.ApplicationAddIns.ItemById("{3BDD8D79-2179-4B11-8A5A-257B1C0263AC}")

            If iLogicAddIn Is Nothing Then
                MsgBox("Add-In iLogic não encontrado.")
                Return
            End If

            ' Garante que o iLogic está ativo
            If Not iLogicAddIn.Activated Then
                Try
                    iLogicAddIn.Activate()
                Catch ex As Exception
                    MsgBox("Erro ao ativar o iLogic Add-In: " & ex.Message)
                    Return
                End Try
            End If

            ' Acesso à automação do iLogic
            Dim iLogicAuto As Object = iLogicAddIn.Automation
            If iLogicAuto Is Nothing Then
                MsgBox("Automação do iLogic não disponível.")
                Return
            End If

            ' Cria regra temporária
            tempFilePath = IO.Path.Combine(IO.Path.GetTempPath(), "RegraTotalizadorTemp.ilogic")
            IO.File.WriteAllText(tempFilePath, codigoIlogic)

            ' Executa a regra externa
            Dim tipoIL As Type = iLogicAuto.GetType()
            Dim metodoRunExternalRule As MethodInfo =
                tipoIL.GetMethod("RunExternalRule", New Type() {GetType(Document), GetType(String)})

            If metodoRunExternalRule Is Nothing Then
                MsgBox("Método RunExternalRule não encontrado na automação iLogic.")
                Return
            End If

            ' --- Execução principal ---
            metodoRunExternalRule.Invoke(iLogicAuto, New Object() {doc, tempFilePath})

            ' Atualiza documento na memória (sem salvar)
            doc.Update()

        Catch ex As Exception
            MsgBox("Erro ao executar o Totalizador de Peças: " & ex.Message)

        Finally
            ' Limpa arquivo temporário
            If Not String.IsNullOrEmpty(tempFilePath) AndAlso IO.File.Exists(tempFilePath) Then
                Try
                    IO.File.Delete(tempFilePath)
                Catch
                    ' Ignora erro ao apagar
                End Try
            End If
        End Try
    End Sub

    ' === Funções auxiliares ===
    Private Function LerRegraIncorporada(parteDoNome As String) As String
        Dim assembly As Assembly = Assembly.GetExecutingAssembly()
        Dim recursos() As String = assembly.GetManifestResourceNames()

        Dim nomeCompleto As String = recursos.FirstOrDefault(
            Function(r) r.IndexOf(parteDoNome, StringComparison.OrdinalIgnoreCase) >= 0
        )

        If String.IsNullOrEmpty(nomeCompleto) Then
            MsgBox("Recurso embutido contendo '" & parteDoNome & "' não encontrado.")
            Return Nothing
        End If

        Using stream As IO.Stream = assembly.GetManifestResourceStream(nomeCompleto)
            If stream Is Nothing Then Return Nothing
            Using reader As New IO.StreamReader(stream)
                Return reader.ReadToEnd()
            End Using
        End Using
    End Function
End Class
