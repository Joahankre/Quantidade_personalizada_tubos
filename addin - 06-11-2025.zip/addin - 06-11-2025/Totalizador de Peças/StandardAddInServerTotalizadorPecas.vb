﻿Imports System.Drawing
Imports System.IO
Imports System.Reflection
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports Inventor

<ComVisible(True)>
<Guid("17834e5b-28ea-4c47-9e61-52efadcdb0c6")>
Public Class StandardAddInServerTotalizadorPecas
    Implements ApplicationAddInServer

    Private _inventorApp As Inventor.Application
    Private _automacaoObj As AutomacaoTotalizadorPecas
    Private meuBotao As ButtonDefinition

    ' Exposição pública do objeto de automação
    Public ReadOnly Property Automation As Object Implements ApplicationAddInServer.Automation
        Get
            Return _automacaoObj
        End Get
    End Property

    ' Ativação do Add-In
    Public Sub Activate(ByVal addInSiteObject As ApplicationAddInSite, ByVal firstTime As Boolean) Implements ApplicationAddInServer.Activate
        _inventorApp = addInSiteObject.Application
        _automacaoObj = New AutomacaoTotalizadorPecas(_inventorApp)

        If Not firstTime Then Return

        Try
            Dim controlDefs As ControlDefinitions = _inventorApp.CommandManager.ControlDefinitions
            Dim assembly As Assembly = Assembly.GetExecutingAssembly()

            ' Carregar ícones embutidos
            Dim smallIcon As IPictureDisp = CarregarIconeEmb(assembly, "TotalizadorPecas.16x16.ico")
            Dim largeIcon As IPictureDisp = CarregarIconeEmb(assembly, "TotalizadorPecas.32x32.ico")

            ' Criar botão ou reutilizar existente
            Try
                meuBotao = DirectCast(controlDefs.Item("MyCompany_TotalizadorPecas"), ButtonDefinition)
            Catch
                meuBotao = controlDefs.AddButtonDefinition(
                    "Totalizador" & vbCrLf & "de Peças",
                    "MyCompany_TotalizadorPecas",
                    CommandTypesEnum.kShapeEditCmdType,
                    "{e038b1a2-14d6-4ba9-aafa-bb31d6b9cf5a}",
                    "Executa a contagem de peças e submontagens na montagem ativa",
                    "Totalizador de Peças",
                    smallIcon,
                    largeIcon)
            End Try

            AddHandler meuBotao.OnExecute, AddressOf BotaoTotalizadorPecas_OnExecute

            ' Adiciona o botão à aba Assembly > Tools
            Dim ribbon As Ribbon = _inventorApp.UserInterfaceManager.Ribbons("Assembly")
            Dim tab As RibbonTab = ribbon.RibbonTabs("id_TabTools")

            Dim painel As RibbonPanel
            Try
                painel = tab.RibbonPanels.Item("PainelTotalizadorPecas")
            Catch
                painel = tab.RibbonPanels.Add("Totalizador de Peças", "PainelTotalizadorPecas", "MyCompany.PanelTotalizadorPecas")
            End Try

            If Not painel.CommandControls.Cast(Of CommandControl)().Any(Function(c) c.ControlDefinition.InternalName = "MyCompany_TotalizadorPecas") Then
                painel.CommandControls.AddButton(meuBotao, True)
            End If

        Catch ex As Exception
            MessageBox.Show("Erro ao inicializar o Add-In: " & ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Desativação do Add-In
    Public Sub Deactivate() Implements ApplicationAddInServer.Deactivate
        Try
            RemoveHandler meuBotao.OnExecute, AddressOf BotaoTotalizadorPecas_OnExecute
        Catch
        End Try

        _inventorApp = Nothing
        _automacaoObj = Nothing
        meuBotao = Nothing
    End Sub

    ' Não utilizado
    Public Sub ExecuteCommand(ByVal commandID As Integer) Implements ApplicationAddInServer.ExecuteCommand
    End Sub

    ' Evento de clique do botão
    Private Sub BotaoTotalizadorPecas_OnExecute(ByVal Context As NameValueMap)
        Try
            _automacaoObj?.ExecutarTotalizadorPecas()
        Catch ex As Exception
            MessageBox.Show("Erro ao executar o Totalizador de Peças: " & ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' === Utilitários ===
    Private Function CarregarIconeEmb(assembly As Assembly, nomeRecurso As String) As IPictureDisp
        Try
            Using stream As Stream = assembly.GetManifestResourceStream(nomeRecurso)
                If stream IsNot Nothing Then
                    Return IconToIPictureDisp(New Icon(stream))
                End If
            End Using
        Catch
        End Try
        Return Nothing
    End Function

    Private Function IconToIPictureDisp(icon As Icon) As IPictureDisp
        Return AxHostConverter.ImageToPictureDisp(icon.ToBitmap())
    End Function

    Private Class AxHostConverter
        Inherits AxHost
        Private Sub New()
            MyBase.New(String.Empty)
        End Sub

        Public Shared Function ImageToPictureDisp(image As Image) As IPictureDisp
            Return CType(GetIPictureDispFromPicture(image), IPictureDisp)
        End Function
    End Class
End Class
