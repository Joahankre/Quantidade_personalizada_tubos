﻿Imports System.Runtime.InteropServices
Imports Inventor
Imports System.Windows.Forms

<ComVisible(True)>
<Guid("613328be-54a0-4b57-a481-db2f8b60cee1")>
Public Interface IAutomacaoTotalizadorPecas
    Sub ExecutarTotalizadorPecas()
End Interface

<ComVisible(True)>
<Guid("d5fa6d2f-5be8-45fd-8581-1dd9f8a2cd6a")>
<ClassInterface(ClassInterfaceType.None)>
Public Class AutomacaoTotalizadorPecas
    Implements IAutomacaoTotalizadorPecas

    Private ReadOnly _app As Inventor.Application

    Public Sub New(app As Inventor.Application)
        _app = app
    End Sub

    Public Sub ExecutarTotalizadorPecas() Implements IAutomacaoTotalizadorPecas.ExecutarTotalizadorPecas
        Try
            Dim gestor As New TotalizadordePecas(_app)
            gestor.ExecutarTotalizadorPecas()
        Catch ex As Exception
            MessageBox.Show("Erro ao executar Totalizador de Peças: " & ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class

